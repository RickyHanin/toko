<?php namespace App\Entities;

use CodeIgniter\Entity;

class Komentar extends Entity
{
	
}